# BioModel Analysis Rules

Use this reference when turning a wastewater-treatment model paper into SIMPO
tables. It preserves the domain requirements used by the backend AI prompt,
adapted for assistant analysis followed by reviewed SIMPO resource creation.

## Paper eligibility

- Confirm that the source is a research paper about a wastewater-treatment
  model, not merely a general treatment paper.
- Search a reliable bibliographic source for the paper's DOI when network access
  is available. If no DOI can be verified, record `DOI unverified` and the
  search/access limitation. A DOI is not evidence of SCI indexing, and its
  absence does not establish `Not SCI`. Missing essential model evidence, not
  a missing DOI alone, is the reason to stop extraction.
- Never let a missing DOI or a failed search turn into an invented citation.

## Evidence and reporting

- Prefer the paper's Components, Parameters, process, and stoichiometric tables.
  Also inspect equations, appendices, and supplements when tables are missing or
  incomplete.
- Do not invent model content. For every correction or derived value, cite the
  source page/table/equation and explain the derivation or correction.
- Return a concise, evidence-based Markdown audit note, not private chain of
  thought. Record extraction choices, corrections, assumptions, and unresolved
  items. Use English for an English paper and Chinese for a Chinese paper.
- This workflow avoids the SIMPO backend AI endpoint, but it does not imply that
  paper contents stay on-device. Follow the data-handling policy of the model
  configured for the user's assistant session.
- Keep the paper title and DOI/citation in this note. A paper DOI is not a
  SIMPO `sourcepaperId`; only attach a source-paper database ID when the user knows the
  database ID.

## Source correction

`source_correction` is a per-run Skill option and defaults to `on`. It is an
evidence-preserving transcription check, not permission to rewrite a paper's
scientific conclusions.

- With `on`, automatically apply only high-confidence corrections supported by
  a direct cross-check: an OCR character error, an obvious copied digit, a
  decimal separator error, a unit-label mismatch confirmed by the same table or
  equation, or a value that is unambiguously contradicted by the paper's own
  adjacent definition. Use the corrected value in the model.
- Do not correct a fitted parameter, empirical coefficient, stoichiometric
  choice, or scientific conclusion merely because it looks unusual, conflicts
  with an external expectation, or improves `Balance`. If evidence conflicts,
  retain the source value and report the conflict as unresolved.
- With `off`, preserve the source representation exactly. Report suspected
  errors, but do not change the extracted value or formula.
- Every applied correction must be written in Markdown in the Description
  audit note, including the source location, original value, corrected value,
  evidence, and confidence. Use this compact format:

  ```markdown
  ## Source corrections
  - Status: applied
  - Location: p. 7, Table 2, `S_NO3` coefficient
    - Original: `0.57`
    - Corrected: `8/14`
    - Evidence: Equation (4) defines a nitrogen-mass basis; the same coefficient is `8/14` in the supplementary table.
    - Confidence: high
  ```

- If no correction is applied, record `## Source corrections` with
  `- Status: none` (or `not applied` when the option is off) and briefly list
  any unresolved suspicion. This keeps the BioModel's provenance auditable.

## Components

Use this exact header row:

```json
{"0":"Symbol","1":"Unit","2":"Name","3":"Description"}
```

- Use the paper's component set. Use `S_` for dissolved components and `X_` for
  particulate components. Place dissolved components before particulate ones.
- If dissolved oxygen is in the model, put `S_O2` or the paper's `S_O` first.
  Preserve the paper's convention; do not add dissolved oxygen when absent.
- Keep oxidation/reduction order meaningful; place nitrate (`S_NO3`) before
  nitrite (`S_NO2`) when both occur. Use a consistent order for remaining
  components and do not duplicate symbols.
- Symbols contain only ASCII letters, digits, and underscores. Do not include
  charge signs, parentheses, hyphens, spaces, or Greek characters. Approximate
  Greek letters with Latin names where appropriate (for example, `u` for
  `mu`).
- Use the paper's unit without spaces. Use `-` for dimensionless values. Use
  `UNKNOWN` only when the paper does not make the unit recoverable, and disclose
  it in the audit note.
- Names and descriptions may be null when absent. Do not fabricate a name or
  description.
- If a symbol truly cannot be recovered, use sequential `S_UNKNOWN_1` or
  `X_UNKNOWN_1` placeholders only after telling the user. Never silently turn an
  uncertain symbol into a factual claim.

## Parameters

Use this exact header row:

```json
{"0":"Symbol","1":"Unit","2":"DefaultValue","3":"LowerBound","4":"UpperBound","5":"Name","6":"Description"}
```

- Parameter symbols start with an ASCII letter and contain only ASCII letters,
  digits, and underscores. Keep them unique and preserve capitalization.
- `T` and `t` are reserved names, not Parameters or Components. Extract water
  temperature into DataSet `Environment`, and use the built-in uppercase `T`
  directly in Rate as described below. Reference temperatures such as `T_ref`
  remain ordinary Parameters when supported by the source.
- Use the value reported by the paper for `DefaultValue` when available. A
  missing lower or upper bound may be null. Do not infer bounds without an
  explicit derivation.
- For time-based units, follow the source prompt's `/d`, `/h`, `/m`, `/s`
  suffix convention. Do not insert spaces. Use `-` for a dimensionless unit.
- If a unit or value cannot be recovered, do not hide that fact. The legacy
  extraction prompt permits `UNKNOWN` for an unknown unit and `-10000` for an
  unknown default; use such sentinels only when necessary, flag each occurrence,
  and obtain user approval before submitting.
- Use sequential `Para_UNKNOWN_1` placeholders only when unavoidable and only
  after disclosing them.

## Stoichiometric Matrix

The header's first cell is `Name`, followed by exactly one column per Component
in the same order, followed by `Rate`:

```json
{"0":"Name","1":"S_O2","2":"S_NO3","3":"X_B","4":"Rate"}
```

- Use a unique process name in the first cell of every data row. Prefer the
  paper's process names; if absent, use `Process1`, `Process2`, and so on and
  disclose the fallback.
- Stoichiometric coefficient cells may be null when the process has no
  coefficient for that Component. Otherwise use formulas containing only
  declared Parameter symbols, numeric literals, and `. + - * / ( )` operators.
  Do not place Component symbols in these cells. Make multiplication explicit
  with `*` and preserve symbol capitalization.
- `Rate` formulas may use declared Component and Parameter symbols, built-in
  water temperature `T`, numeric literals, and `. + - * / ** ( )` operators.
  `**` is exponentiation, not a display-only superscript. Do not invent identifiers. If a
  rate cannot be recovered, use `-10000` only as an explicitly disclosed
  placeholder and require user approval.
- Convert stoichiometric decimals to simple exact fractions when the paper's
  convention supports it. Common nitrogen-basis conversions include `0.57` to
  `8/14`, `1.71` to `24/14`, `2.29` to `32/14`, `3.43` to `48/14`, `4.57` to
  `64/14`, and `6.85` to `96/14`. Do not replace `1` with `14/14`.
- Apply the per-run `matrix_fractions` option. When enabled, normalize a rounded
  coefficient in Matrix or Composition only if its exact value follows from a
  cited equation, molecular/elemental basis, or transparent derivation. For
  example, the Xu et al. (2016) AD equations and biomass formula support
  `1.239 -> 140/113`, `0.826 -> 280/339`, `2.832 -> 320/113`, and
  `0.944 -> 320/339`; preserve the paper's rounded values in the audit note and
  identify the derivation for the stored fractions. Never infer a rational
  value from a decimal alone (including with a bounded-denominator
  approximation), and never convert fitted estimates or empirical coefficients
  without an independent exact derivation. When the option is off, preserve the
  source notation.

## Environmental temperature in Rate

The built-in uppercase `T` is water temperature in °C for the reaction's Tank
and current time. It comes from `DataSet.Environment`; it is neither an
estimated `Solution.Variable` nor a Component with a mass balance. A missing
Tank series uses **20°C**. Point-settler zones use their own series first,
then their parent's. The supported input range is **0–40°C**. Follow the
DataSet Skill's `dataset-json-format` reference for series shape, input event
protection, interpolation, and averaging.

For a source-supported temperature correction, keep the reference rate constant
and temperature coefficient as Parameters, and put the temperature-dependent
factor in `Matrix.Rate`, for example:

```text
mu_H20 * theta_H**(T - 20) * S_S/(K_S + S_S) * X_H
```

Here `mu_H20`, `theta_H`, and `K_S` must be declared Parameters, and `S_S` and
`X_H` declared Components. `theta_H` is independent of the Pump's oxygen-transfer
`θ`. Do not manufacture a temperature coefficient merely because T is now
supported. If the source uses Kelvin, translate explicitly as `T + 273.15` in
the Rate and preserve the source equation and unit conversion in the audit.

Never define a Parameter such as `mu_H = mu_H20 * theta_H**(T - 20)` or move
that factor to a stoichiometric cell: these fields are static. `T` is allowed
only in `Matrix.Rate`, not in Parameter values/bounds, stoichiometric
coefficients, Composition, Formula, or Ionization. Fixed parameter factors may
be extracted internally; T-dependent factors must remain evaluated at runtime.
Do not rename a source quantity unrelated to water temperature to T. If an old
model has a Parameter/Component named `T` or `t`, resolve its meaning and rename
that symbol and its references before saving; never silently discard its value.

For steady state, SIMPO evaluates the Rate at the Tank's average temperature
according to `steady_state_input_average_method`; this differs from averaging
a nonlinear corrected Rate. The dynamic phase restores the original series.
Rates with T currently require **Forward Euler**; Improved Euler rejects them.
Keep plain `T` and `**` expressions in JSON/XLSX. The frontend's colored badge
and closed-cell exponent superscript are presentation only.

## Substrate depletion and nonnegativity

Perform this scientific check for each process/Component pair with a consuming
stoichiometric contribution. It remains required when `source_correction` is
off; report findings separately from transcription corrections.

- Determine coefficient signs from the declared parameter values and supported
  ranges, not from the presence of a minus sign in the cell text. If a sign or
  rate direction is uncertain or changes over the supported domain, record the
  conditions and mark the unresolved cases explicitly.
- For a dynamic concentration `C_j` with `nu_ij < 0` and a nonnegative forward
  rate `r_i`, verify that the rate vanishes at `C_j = 0`, with the other states
  in their admissible domain. Check each consumed Component separately. For a
  signed reversible rate, inspect both consuming directions through the signed
  contribution `nu_ij * r_i`; a negative matrix coefficient alone does not
  identify consumption in the reverse direction.
- Inspect the full expression and declared Formula dependencies. Merely finding
  the Component symbol in Rate is insufficient. `C_j/(K + C_j)` with `K > 0`
  provides depletion protection, as does a finite rate proportional to `C_j`,
  such as biomass decay `b * X_B`. Do not multiply by another Monod factor when
  an equivalent constraint already exists. An inhibition term `K/(K + C_j)` or
  a positive constant does not shut the reaction off at depletion. Undefined
  denominators, including `0/0`, are unresolved rather than evidence of safety.
- Follow Formula dependencies on their feasible state domain instead of setting
  an algebraically dependent Component independently to zero. A fixed external
  reservoir or an explicit reaction-availability constraint may justify a
  different treatment only with evidence of how it is represented and enforced.
  Do not assume a solver prevents depletion or treat an ordinary dynamic state
  as an inexhaustible reservoir to excuse a missing constraint.
- When a constraint is missing, retain the original expression and propose an
  evidenced remedy. A candidate is `Rate_original * C_j/(K_switch + C_j)`, with
  `K_switch > 0` and the same concentration unit as `C_j`. Record its source or
  explicit modeling assumption and the effect on the original kinetics. Do not
  invent a value, use zero, or choose an unexplained tiny value solely to pass
  the check. If the parameter basis is missing, leave the remedy unresolved.
  Expand the original Rate when writing SIMPO tables; `Rate_original` here is
  explanatory notation, not a new allowed symbol.

Record each checked pair in the Description audit with process, Component,
coefficient/sign conditions, original Rate, zero-boundary evidence, and status
(`protected`, `missing`, `unresolved`, or `not_applicable` with a reason). For
changes, also record the proposed/applied Rate, new parameters and their units
and basis, and the user's modeling decision. Present the findings in the normal
creation review. Preserve source values for exact workbook imports and report
suggestions separately. A new availability factor is a **kinetic extension /
depletion protection**, not an automatic source correction; apply it only when
its scientific assumptions and parameters are resolved within the reviewed
model specification. Do not silently change a fitted rate or claim the paper
contained the added term.

Passing this boundary check is not proof that an entire simulation stays
nonnegative: discretization, solver tolerances, transport, and other processes
still need validation. A zero `Balance` residual does not establish depletion
protection either.

### Example: elemental sulfur in Xu et al. (2016)

In [Xu et al. (2016)](https://doi.org/10.1016/j.watres.2016.01.011), Table S1
(supplement p. 3), processes C and D consume elemental sulfur (`S_S0` when that
symbol is used in the imported model). Their Rates contain `eta(S)`, and the
main text, section 4, deliberately adopts a constant sulfur term after comparing
it with a Monod term. A positive constant does not provide depletion protection
for a dynamic `S_S0`; flag that boundary behavior without labeling the author's
choice a transcription error. A proposed extension can retain the original
`eta(S)` and multiply each original C/D Rate by
`S_S0/(K_switch_S0 + S_S0)`. The added parameter needs its own units, basis, and
review; it is not a reported paper parameter. Preserve the original expressions
and compare the extension's behavior near depletion and over the calibration
range before claiming equivalence or validity.

## Composition

`Composition` contains balance coefficients; it is distinct from the
read-only `Balance` result. If the paper omits it and derivation is requested or
useful, read `references/composition-derivation.md` and follow that workflow in
full. Derive and submit supported cells independently; do not require the table
to be balanced before creation.
When included:

- Use the exact first header value `Balances \\ Components` (one literal
  backslash, escaped as `\\` in JSON), then one column per Component in the
  same order as the Matrix:

  ```json
  {"0":"Balances \\ Components","1":"S_O2","2":"S_NO3"}
  ```
- Include balance rows in this order: `ThOD`, `N`, `P`, `S`, `Charge`, `TSS`.
  Keep all six rows in this order when providing a Composition table; use
  `null` only when a coefficient is genuinely unavailable. A defensible zero is
  different from an unknown `null`.
- Composition cells contain only declared Parameter symbols, numeric literals,
  and `. + - * / ( )` operators. Do not use Component symbols inside formulas.
- Derive coefficients from the paper or explicit elemental, charge, oxygen
  demand, or solids balances. Cite the source or derivation. Do not present a
  guessed balance as extracted fact.
- Treat an absent Composition as missing information, not permission to insert
  generic ASM coefficients. Establish the reporting basis, formula/speciation,
  charge, and solids basis separately for each supported cell. Leave unsupported
  cells `null` and explain them in the audit note. Omit the whole table only when
  no cell has defensible evidence.
- Do not remove a supported Component or coefficient because it makes
  `Balance` nonzero. `Balance` is a backend diagnostic that can expose an
  omitted Component, an unknown coefficient, a basis mismatch, or a genuinely
  non-closed paper model. Do not fit coefficients, add unreported Components, or
  alter the Matrix solely to force zero residuals.
- Examples of SIMPO reference checks include ThOD coefficients
  for `S_NO3=-64/14`, `S_NO2=-48/14`, `S_NO=-40/14`, `S_N2O=-32/14`,
  `S_N2=-24/14`, `S_NH2OH=-16/14`, `S_SO4=-2`, `S_CH4=1`, and `S_O2=-1`;
  nitrogen or phosphorus content parameters must be referenced by their exact
  declared Parameter symbols. These are checks, not values to add when the
  model does not contain those Components.

## Ionization

`Ionization` defines the acid/base contribution of dissolved Components to
SIMPO's RIIC/pH calculation. Match species and concentration basis to the built-in
SIMPO reference parameters in the derivation workflow. These defaults can be
used without live lookup or paper-provided pK values; disclose their source and
any condition limitations. Use applicable paper/user values when provided.
Do not invent missing species or temperature corrections. If Ionization is requested or useful,
read `references/ionization-derivation.md` and follow it in full.

- Use the exact header `Symbol`, `Compound`, `Step`, `Ionization`, `Factor`,
  `pK1`, `pK2`, `pK3`, `pKw` in that order.
- Include only unique dissolved `S_` Component symbols, matching the frontend
  workflow.
- Derive `Factor` from the Component's actual reporting basis; for example,
  NO3-N uses the molar mass of N, not the full nitrate ion.
- Treat all selected pK values, conversions, temperature assumptions, and
  SIMPO defaults or external references as auditable model decisions. Do not
  guess missing values or describe defaults as paper-extracted.
- Put pKw only in the first data row and keep unused pK fields null.
- Do not add `pH` to Component. A Project needs a DataSet `pH` Target and a
  Project Conversion mapping to expose pH results.

## JSON submission shape

Submit model tables only. Do not include the paper title, `Description`, or
`Balance` as root keys in the submitted table JSON. Put citation and concise analysis
notes in the BioModel Description.

```json
{
  "Component": [
    {"0":"Symbol","1":"Unit","2":"Name","3":"Description"},
    {"0":"S_O2","1":"gO2/m3","2":"Dissolved oxygen","3":null}
  ],
  "Parameter": [
    {"0":"Symbol","1":"Unit","2":"DefaultValue","3":"LowerBound","4":"UpperBound","5":"Name","6":"Description"},
    {"0":"k","1":"/d","2":0.1,"3":0,"4":1,"5":"Rate coefficient","6":null}
  ],
  "Matrix": [
    {"0":"Name","1":"S_O2","2":"Rate"},
    {"0":"Removal","1":"-1","2":"k*S_O2"}
  ],
  "Composition": [],
  "Ionization": []
}
```

`Component`, `Parameter`, and `Matrix` are required. `Composition` and
`Ionization` are optional. Do not create an `Ionization` table from guesswork;
use the dedicated derivation workflow and omit the table when evidence is
insufficient. Never include `Balance`, even
when reusing a BioModel read response: the API rejects it and computes
the result itself.
