# DataSet and Project Commands

Run the requested command directly. The CLI and backend enforce authentication,
ownership, and the indicated scope; do not perform routine help or permission
checks before a read or write.

If a requested command returns an unknown-command or unsupported-operation error,
consult its `--help` and update SimpoCLI when needed. Never fall back to direct
API requests; the references describe the newer command surface without
pretending it exists in every package.

## DataSets

| Task | Command | Scope |
| --- | --- | --- |
| Create a Draft DataSet | `create-dataset NAME [--json DETAIL.json] [--async]` | `write` |
| List owned DataSet metadata | `get-datasets` | `read` |
| Read complete DataSet tables | `get-dataset DATASET_ID` | `read` |
| Update a Draft DataSet | `update-dataset DATASET_ID --json DETAIL.json` | `write` |
| Copy a published DataSet to its Draft | `sync-dataset DATASET_ID` | `write` |
| Release a Draft DataSet | `release-dataset DATASET_ID [--privacy Private|Public]` | `write` |

List results are paginated. Traverse all pages when resolving a DataSet by name.
Use the positive database ID with `get-dataset`; report the identity metadata
and only the tables relevant to the user's request. A JSON DataSet contains the
complete editable detail object returned by `get-dataset`; updates are parsed
before saving and rebuild Projects that use the Draft.

When Target, Tank, Inflow, or Flow identifiers change, the backend compares the
stored Draft with the submitted JSON and automatically creates the same
`changeValueDataSet` dictionary used by the web editor. Tank, Inflow, and Flow
share the `TankInflowFlow` group because all three identify Project Variable and
Weight dimensions. No mapping file is required.

Updating a Draft rebuilds dependent Project detail and serialized caches, sets
`dataset_draft_changed`, preserves compatible user-entered values through the
automatically derived change-value dictionary, and marks every existing calculation engine result as requiring
recalculation.

For create and update responses, require `success: true` and a positive `id`.
For `update-dataset`, also report `affectedProjectCount`. For synchronization,
require `sourceId` to equal the input Release ID and treat `id` as the target
Draft ID. For release, require `sourceId` to equal the input Draft ID, treat
`id` as the new Release ID, and require `version >= 1`.

## Projects

| Task | Command | Scope |
| --- | --- | --- |
| Create a Draft Project | `create-project NAME --biomodel-id ID --dataset-id ID [--json DETAIL.json] [--async]` | `write` |
| List owned Project metadata | `get-projects` | `read` |
| Read complete Project detail | `get-project PROJECT_ID` | `read` |
| Read all Solution Variable fields | `get-project-variables PROJECT_ID` | `read` |
| Update one Variable field | `set-project-variable PROJECT_ID VARIABLE VALUE` | `write` |
| Update a Draft Project | `update-project PROJECT_ID --json DETAIL.json [--async]` | `write` |
| Copy a published Project to its Draft | `sync-project PROJECT_ID` | `write` |
| Release a Draft Project | `release-project PROJECT_ID [--privacy Private|Public]` | `write` |

Use `get-projects` and traverse pagination only when a name must be resolved to
an ID. When the user already supplied an exact ID, run the requested lifecycle
command directly. For `set-project-variable`, read the current Variable table
and select the row using both the exact Variable name and `--tank` when the row
is tank-specific.

`create-project` builds the Solution from the selected BioModel and DataSet.
Without `--json`, it generates the default Solution tables. With `--json`, it
parses the supplied Solution detail during creation. Use the same
detail shape returned by `get-project`: `Variable`, `Target`, `Conversion`, and
`Weight` are required; `Activator`, `Constraint`, and legacy `Retention` may be omitted.
Activator will be generated when needed. Use `update-project` to replace the detail of an existing Draft.
Updating Project detail rebuilds the Solution cache and removes results that no
longer match it.

`Constraint` is an optional list of named records with exactly `Tank`,
`Component`, `Target`, and `Interpolation`. It forces the selected Component in
the Tank to follow the matching DataSet Measured Target. References must exist,
Target and Component units must match, each Tank/Component pair must be unique,
and `Interpolation` must be `Previous` or `Linear`. The first Measured value
cannot be empty; a constrained Measured series is removed from the weighted
fitting objective. A common candidate is tank-specific measured DO when the
case lacks sufficient aeration/oxygen-transfer inputs such as kLa or Qair:
map the actual DO Target and Component, propose the Constraint, and document
the imposed-DO assumption instead of inventing aeration data. A measured scalar
needs a justified time interval/constant-series assumption. Do not constrain
all observations by default; other uses need a source/user-defined reason.
Constraint is enabled in `dynamic`, disabled in `steady_state`, and enabled
only after the steady-state phase in `steady_state_then_dynamic`; it cannot
replace missing physical oxygen supply during steady-state initialization.

`Retention` is a named-record list with exactly one row per DataSet Tank and
fields `Tank`, `HRT`, and `SRT`. HRT/SRT are booleans. HRT selects Tank volumes
for the system hydraulic-retention numerator; SRT selects Tank TSS inventories
for the solids-retention numerator. SRT requires a DataSet Target with
`StandardTarget: "Total Suspended Solids"` and a nonempty Conversion row.
For a settling tank, set `HRT=false` when `BioCalculated=false` (the usual case),
and `HRT=true` when `BioCalculated=true`. With the TSS StandardTarget and a valid
Conversion, enable SRT for tanks holding the system sludge inventory, including
settling tanks even if their HRT/BioCalculated flags are false. Without the TSS
mapping, leave SRT off and report the missing prerequisite. Auxiliary virtual
tanks, such as a dedicated chemical phosphorus removal tank, normally use
`HRT=true` and `SRT=false`, even when TSS mapping exists. Identify them by their
documented modeling role and record any case-specific exception; do not enable
SRT for every tank solely because the TSS Target is present. Legacy input may
generate HRT=true for every tank; review and explicitly set the intended
accounting boundary. These flags select statistics, not biological activity or
physical solids retention, and cannot fix bacterial washout.

`create-dataset` and `update-dataset` also accept `--async`, `--wait`,
`--operation-wait-timeout`, `--operation-poll-interval`, and
`--idempotency-key`. The backend performs the same parsing, automatic
`changeValueDataSet` mapping, and linked Project synchronization in either
mode.

When a Project is later calculated, `Solution.Variable.Value` is the runtime
baseline for `Inflow` and `Flow`. The backend additively shifts each complete
series from its DataSet `time=0` value (`Inflow` first resolves and applies its
selected Conversion expression), clips negative values, and converts Flow to
`m3/s`.
`Measured` is not shifted; it remains the original observation series. See
[Calculation commands](calculation.md) for the formulas and an example.

The default Solution only provides identity mappings for Targets whose symbols
match BioModel Components. For aggregate Targets such as `COD`, `TIN`, `TN`,
`TP`, `TSS`, or `TS`, inspect and complete `Conversion` explicitly before
creating the Project. Use coefficients supported by the source definition,
BioModel Composition, or a transparent unit conversion; coefficients may be
literal numbers or expressions/direct BioModel Parameter references. Preserve a
defined Parameter such as `i_N_S_U` in the Conversion cell instead of forcing
its current value into a number. The calculation resolves it from the current
Project Variable values. Verify that referenced Parameters exist, are finite,
and are unit-compatible; do not infer a formula from the Target abbreviation
alone. For example, standard `TIN` may map to
`S_NHx=1` and `S_NOx=1`, while `TSS` normally uses model-specific `i_TSS_*`
coefficients for particulate Components. Do not add `S_N2` to TIN without a
source definition, and in this BioModel context interpret `TS` as total sulfur,
not total solids or a synonym for TSS. Use `--json` for
reviewed mappings and record formulas and units in the Project description. A
structurally valid but blank or all-zero Conversion row is not a valid
scientific mapping. The same rule applies to any other Target: resolve its
meaning and units, use direct identity first, derive only source/Composition-
supported coefficients, and stop as `unresolved` when candidates conflict or
the component fractionation is underdetermined. Nonlinear definitions or
definitions requiring an absent state variable cannot be represented by
Conversion alone.

For synchronization, the command argument is the Release ID and the response
contains the target Draft ID. For release, the argument is the Draft ID and the
response contains a new Release ID. Treat these as different records.

For Project create and update responses, require `success: true` and a positive
`id`. For synchronization, require `sourceId` to equal the input Release ID and
treat `id` as the target Draft ID. For release, require `sourceId` to equal the
input Draft ID, treat `id` as the new Release ID, and require `version >= 1`.

With `--async`, Project create/update returns `operationId` and an initial
`status` instead of a Project result. Add `--wait` to wait for the operation and
receive the final Project JSON, or use `wait-operation` separately. For retries,
pass a stable `--idempotency-key`; reusing it with a different payload is a
backend conflict and must be corrected rather than retried blindly.

## Update a Variable safely

Only an owned version 0 Draft Project is writable. Read the installed command
help for the allowed `--field` values and value syntax when needed. Common examples include
numeric `Value`, `LowerBound`, or `UpperBound`; Boolean `Evaluation`; integer
`DecimalPoint`; and nullable metadata fields. `Variable` and `Tank` identify a
row and are not writable fields.

Before running the command, show or internally verify:

- Project ID, name, state, and version;
- exact Variable and optional Tank;
- target field, current value, and proposed value;
- bounds or type restrictions returned by the current Project data.

After success, require `success: true` and verify that the returned Project,
Variable, Tank, field, old value, and new value match the intended update. Read
the row again when the response is incomplete or the outcome is ambiguous.

Do not bulk-edit variables by constructing repeated commands unless the user
explicitly requested every change and each row/value has been validated.
