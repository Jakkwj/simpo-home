# Token and CLI Basics

## Command map

| Task | Command | Scope |
| --- | --- | --- |
| Show version or discover commands | `simpo --version`, `simpo --help` | none |
| Validate and save a Token | `simpo configure` | Token validation must succeed |
| Show current identity and scopes | `simpo me` | authenticated Token |
| Remove the saved local Token | `simpo logout` | none |
| Read an asynchronous operation | `simpo get-operation OPERATION_ID` | `read` |
| Wait for an asynchronous operation | `simpo wait-operation OPERATION_ID` | `read` |
| Cancel a queued operation | `simpo stop-operation OPERATION_ID` | `write` |

Run the requested command directly. Different installed versions may expose
different commands; let the CLI report an
unsupported command or option instead of performing routine discovery first.

## Configure without leaking a Token

Run `simpo configure` in an interactive terminal. It reads the Token through a
hidden prompt, validates it, and saves it in the user profile. Do not pass the
Token through chat, shell history, committed environment files, or generated
scripts.

For normal use, rely on the saved Token. `--api-token` and the
`SIMPO_API_TOKEN` environment variable are temporary override mechanisms and
must not be printed or persisted. `--base-url` is an explicit backend override; omit
it unless the user explicitly targets another backend.

Use `simpo me` when the user explicitly asks for identity/scopes or when
diagnosing an authentication problem. Normal operations should be attempted
directly; the CLI and backend enforce the required scopes:

- `read`: list/read BioModels, DataSets, Projects, Project Variables, and calculation results;
- `write`: create/update/sync/release BioModels, DataSets, and Projects, and update Project Variables;
- `calculate`: prepare, inspect, and stop calculations.

## CLI and Skills updates

Starting with CLI 0.1.8, use these commands only when the user requests maintenance:

```bash
simpo update --check
simpo update
simpo skills list --target codex
simpo skills install --target codex
simpo skills update --target codex --check
simpo skills update --target codex
```

Use `--target claude` for Claude Code local-directory Skills. Installing
`simpo-create-project` includes all three dependencies. Omitted names install
all four or update installed Skills. Skills share `X.Y.Z-skills.N` versions;
CLI compatibility is declared separately. Neither update operation needs an API
Token. Old CLIs lacking these commands require a downloaded installer first.

Linux CLI updates use sudo/dpkg. Windows returns `scheduled` while a detached
installer waits for the CLI to exit; UAC may appear. Read the returned
`status_file` and `installer_log` to confirm `installed` or diagnose `failed`.
Do not report a scheduled update as installed. Skills updates require a new
assistant session. Manual installations and modified files require explicit
`--force`, which backs them up before replacement; report the backup location.
Claude Marketplace plugins remain managed through Claude's `/plugin` manager;
the CLI never writes plugin caches or installs local duplicates. Local Claude
Skills use `/simpo` instead of `/simpo:simpo`.

## Output and automation

Successful results are JSON on stdout. Progress and errors go to stderr. In a
script, capture them independently and parse stdout only after checking the exit
status. Never log a result field documented as secret, including a calculation
`launchProtocol` requested with `--print-protocol`.

List endpoints are paginated. Use the pagination fields returned by the command
and continue until every page has been visited. Consult `--help` only when the
pagination syntax is unclear or the command reports a usage error.

`simpo logout` removes only the local Token file. It does not revoke the Token on
the SIMPO server; revoke it from the Dashboard when server-side invalidation is
required.

## Failure handling

- `401`: reconfigure a valid, non-expired Token; never request it in chat.
- `403`: relay the backend scope/permission error; use `simpo me` only when
  diagnosing the authentication or scope problem, then obtain the missing
  scope through the Dashboard.
- unknown command or unsupported option: consult the relevant `--help` and
  update SimpoCLI if the operation is not available; never call the OpenAPI
  directly to bypass the CLI.
- network or timeout after a write: inspect the affected resource before retrying.

## Asynchronous operations

The backend keeps long-running Project create/update and calculation-preparation
requests in a durable Operation record. Normal CLI behavior remains synchronous.
When an asynchronous option is selected, the command returns an `operationId`
and does not mean that the resource has been written. Use `wait-operation` or
poll `get-operation` until `status` is `succeeded`, `failed`, or `cancelled`.

Failed records preserve `errorCode` and `errorMessage`; relay both fields when
explaining the failure. A queued operation can be cancelled with
`stop-operation`. A running operation is not falsely marked cancelled; for a
running calculation use `stop-calculation`.
